if SERVER then
	util.AddNetworkString("sendCommsMsg")
	util.AddNetworkString("sendOOCMsg")

	if (cfgComms == NULL || cfgComms.colorComms == NULL || cfgComms.colorOOC == NULL) then 
		Error("You haven't installed the Github addon >_<") 
		
		function cUpdateColor2()
			for k,v in pairs(player.GetAll()) do
				v:SetNWInt("commsrgb_r",255)
				v:SetNWInt("commsrgb_g",255)
				v:SetNWInt("commsrgb_b",255)
			end
			for k,v in pairs(player.GetAll()) do
				v:SetNWInt("oocrgb_r",255)
				v:SetNWInt("oocrgb_g",255)
				v:SetNWInt("oocrgb_b",255) 
			end
		end

		hook.Add("Think","thinklikecomms",function()
			cUpdateColor2()
		end)
		hook.Add("Initialize","commsLoad",function()
			if (file.Exists("comms/settings.txt","DATA")) then
				file.Delete("comms/settings.txt","DATA")
			end
			if (file.Exists("comms/tutorial.txt","DATA")) then
				file.Write("comms/tutorial.txt","Hi, to get the config working you need to download the addon from github, which can be found in the description of this addon!")
			end
		end)
		hook.Add( "PlayerSay", "CommsOOC", function(ply, text, public )
			if (string.sub(text, 1, 4) == "/ooc") then
				if (cfgComms.occ == false) then return end
				net.Start("sendOOCMsg")
					net.WriteString(tostring(ply:Nick())..": "..string.sub(text,5))
				net.Send(player.GetAll())
				return ""
			end
			if (string.sub(text, 1, 6) == "/comms") then
				if (cfgComms.comms == false) then return end
				net.Start("sendCommsMsg")
					net.WriteString(tostring(ply:Nick())..": "..string.sub(text,7))
				net.Send(player.GetAll())
				return ""
			end
		end)
	return end
	function cUpdateColor()
		for k,v in pairs(player.GetAll()) do
			v:SetNWInt("commsrgb_r",cfgComms.colorComms[1])
			v:SetNWInt("commsrgb_g",cfgComms.colorComms[2])
			v:SetNWInt("commsrgb_b",cfgComms.colorComms[3])
			v:SetNWInt("oocrgb_r",cfgComms.colorOOC[1])
			v:SetNWInt("oocrgb_g",cfgComms.colorOOC[2])
			v:SetNWInt("oocrgb_b",cfgComms.colorOOC[3])
		end
	end

	hook.Add("Think","thinklikecomms",function()
		cUpdateColor()
	end)

	hook.Add("Initialize","commsLoad",function()
		if (file.Exists("comms/settings.txt","DATA")) then
			file.Delete("comms/settings.txt","DATA")
		end
		if (file.Exists("comms/tutorial.txt","DATA")) then
			file.Write("comms/tutorial.txt","Hi, to get the config working you need to download the addon from github, which can be found in the description of this addon!")
		end
	end)
	hook.Add( "PlayerSay", "CommsOOC", function(ply, text, public )
		if (string.sub(text, 1, 4) == "/ooc") then
			if (cfgComms.occ == false) then return end
			net.Start("sendOOCMsg")
				net.WriteString(tostring(ply:Nick())..": "..string.sub(text,5))
			net.Send(player.GetAll())
			return ""
		end
		if (string.sub(text, 1, 6) == "/comms") then
			if (cfgComms.comms == false) then return end
			net.Start("sendCommsMsg")
				net.WriteString(tostring(ply:Nick())..": "..string.sub(text,7))
			net.Send(player.GetAll())
			return ""
		end
	end)
end